package com.monk.apis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestMonkApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestMonkApplication.class, args);
	}

}
