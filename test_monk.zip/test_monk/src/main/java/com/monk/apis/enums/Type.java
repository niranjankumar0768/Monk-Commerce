package com.monk.apis.enums;

public enum Type {

	CART_WISE, PRODUCT_WISE, BxGy

}
